package flowDomain;

/**
 *	Generated from IDL interface "FDIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface FDIterator_I
	extends FDIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
