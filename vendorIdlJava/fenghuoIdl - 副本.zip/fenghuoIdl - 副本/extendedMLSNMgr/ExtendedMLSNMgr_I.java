package extendedMLSNMgr;

/**
 *	Generated from IDL interface "ExtendedMLSNMgr_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface ExtendedMLSNMgr_I
	extends ExtendedMLSNMgr_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity, common.Common_I
{
}
