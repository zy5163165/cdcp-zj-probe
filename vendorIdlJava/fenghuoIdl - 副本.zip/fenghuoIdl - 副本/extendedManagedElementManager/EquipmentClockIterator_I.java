package extendedManagedElementManager;

/**
 *	Generated from IDL interface "EquipmentClockIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface EquipmentClockIterator_I
	extends EquipmentClockIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
