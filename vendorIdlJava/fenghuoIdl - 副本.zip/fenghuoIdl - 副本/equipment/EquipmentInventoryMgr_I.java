package equipment;

/**
 *	Generated from IDL interface "EquipmentInventoryMgr_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface EquipmentInventoryMgr_I
	extends EquipmentInventoryMgr_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity, common.Common_I
{
}
