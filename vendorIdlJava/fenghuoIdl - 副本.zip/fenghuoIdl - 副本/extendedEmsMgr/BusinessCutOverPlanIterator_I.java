package extendedEmsMgr;

/**
 *	Generated from IDL interface "BusinessCutOverPlanIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface BusinessCutOverPlanIterator_I
	extends BusinessCutOverPlanIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
