package emsMgr;

/**
 *	Generated from IDL interface "EMSMgr_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface EMSMgr_I
	extends EMSMgr_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity, common.Common_I
{
}
