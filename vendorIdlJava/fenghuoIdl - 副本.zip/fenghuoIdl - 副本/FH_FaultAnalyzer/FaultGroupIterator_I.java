package FH_FaultAnalyzer;

/**
 *	Generated from IDL interface "FaultGroupIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface FaultGroupIterator_I
	extends FaultGroupIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
