package callSNC;

/**
 *	Generated from IDL definition of struct "CallCreateData_T"
 *	@author JacORB IDL compiler 
 */

public final class CallCreateData_T
	implements org.omg.CORBA.portable.IDLEntity
{
	public CallCreateData_T(){}
	public globaldefs.NameAndStringValue_T[] callName;
	public java.lang.String userLabel = "";
	public boolean forceUniqueness;
	public java.lang.String owner = "";
	public java.lang.String networkAccessDomain = "";
	public callSNC.CallEnd_T aEnd;
	public callSNC.CallEnd_T zEnd;
	public callSNC.CallParameterProfile_T callParameters;
	public callSNC.Diversity_T callDiversity;
	public globaldefs.NameAndStringValue_T[] additionalCreationInfo;
	public CallCreateData_T(globaldefs.NameAndStringValue_T[] callName, java.lang.String userLabel, boolean forceUniqueness, java.lang.String owner, java.lang.String networkAccessDomain, callSNC.CallEnd_T aEnd, callSNC.CallEnd_T zEnd, callSNC.CallParameterProfile_T callParameters, callSNC.Diversity_T callDiversity, globaldefs.NameAndStringValue_T[] additionalCreationInfo)
	{
		this.callName = callName;
		this.userLabel = userLabel;
		this.forceUniqueness = forceUniqueness;
		this.owner = owner;
		this.networkAccessDomain = networkAccessDomain;
		this.aEnd = aEnd;
		this.zEnd = zEnd;
		this.callParameters = callParameters;
		this.callDiversity = callDiversity;
		this.additionalCreationInfo = additionalCreationInfo;
	}
}
