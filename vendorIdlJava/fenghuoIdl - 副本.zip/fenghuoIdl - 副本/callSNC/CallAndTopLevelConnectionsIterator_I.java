package callSNC;

/**
 *	Generated from IDL interface "CallAndTopLevelConnectionsIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface CallAndTopLevelConnectionsIterator_I
	extends CallAndTopLevelConnectionsIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
