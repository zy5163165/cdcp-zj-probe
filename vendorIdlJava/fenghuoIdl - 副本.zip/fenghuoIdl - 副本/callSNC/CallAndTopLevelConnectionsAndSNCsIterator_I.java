package callSNC;

/**
 *	Generated from IDL interface "CallAndTopLevelConnectionsAndSNCsIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface CallAndTopLevelConnectionsAndSNCsIterator_I
	extends CallAndTopLevelConnectionsAndSNCsIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
