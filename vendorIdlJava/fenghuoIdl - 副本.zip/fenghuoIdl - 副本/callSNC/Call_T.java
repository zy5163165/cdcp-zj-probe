package callSNC;

/**
 *	Generated from IDL definition of struct "Call_T"
 *	@author JacORB IDL compiler 
 */

public final class Call_T
	implements org.omg.CORBA.portable.IDLEntity
{
	public Call_T(){}
	public globaldefs.NameAndStringValue_T[] callName;
	public java.lang.String userLabel = "";
	public java.lang.String owner = "";
	public java.lang.String networkAccessDomain = "";
	public java.lang.String nativeEMSName = "";
	public java.lang.String callId = "";
	public java.lang.String callState;
	public callSNC.CallEnd_T aEnd;
	public callSNC.CallEnd_T zEnd;
	public callSNC.CallParameterProfile_T callParameters;
	public callSNC.Diversity_T callDiversity;
	public java.lang.String diversitySynthesis = "";
	public callSNC.DiversityInfo_T linkDiversityViolations;
	public callSNC.DiversityInfo_T nodeDiversityViolations;
	public callSNC.DiversityInfo_T[] linkPartialDiversityList;
	public callSNC.DiversityInfo_T[] nodePartialDiversityList;
	public globaldefs.NameAndStringValue_T[] callAdditionalInfo;
	public Call_T(globaldefs.NameAndStringValue_T[] callName, java.lang.String userLabel, java.lang.String owner, java.lang.String networkAccessDomain, java.lang.String nativeEMSName, java.lang.String callId, java.lang.String callState, callSNC.CallEnd_T aEnd, callSNC.CallEnd_T zEnd, callSNC.CallParameterProfile_T callParameters, callSNC.Diversity_T callDiversity, java.lang.String diversitySynthesis, callSNC.DiversityInfo_T linkDiversityViolations, callSNC.DiversityInfo_T nodeDiversityViolations, callSNC.DiversityInfo_T[] linkPartialDiversityList, callSNC.DiversityInfo_T[] nodePartialDiversityList, globaldefs.NameAndStringValue_T[] callAdditionalInfo)
	{
		this.callName = callName;
		this.userLabel = userLabel;
		this.owner = owner;
		this.networkAccessDomain = networkAccessDomain;
		this.nativeEMSName = nativeEMSName;
		this.callId = callId;
		this.callState = callState;
		this.aEnd = aEnd;
		this.zEnd = zEnd;
		this.callParameters = callParameters;
		this.callDiversity = callDiversity;
		this.diversitySynthesis = diversitySynthesis;
		this.linkDiversityViolations = linkDiversityViolations;
		this.nodeDiversityViolations = nodeDiversityViolations;
		this.linkPartialDiversityList = linkPartialDiversityList;
		this.nodePartialDiversityList = nodePartialDiversityList;
		this.callAdditionalInfo = callAdditionalInfo;
	}
}
