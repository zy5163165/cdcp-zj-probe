package common;

/**
 *	Generated from IDL interface "Common_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface Common_I
	extends Common_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
