package extendedPerformanceMgr;

/**
 *	Generated from IDL interface "ExtendedPerformanceMgr_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface ExtendedPerformanceMgr_I
	extends ExtendedPerformanceMgr_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity, common.Common_I
{
}
