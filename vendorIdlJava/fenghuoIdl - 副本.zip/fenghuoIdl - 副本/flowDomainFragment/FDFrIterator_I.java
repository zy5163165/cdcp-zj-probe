package flowDomainFragment;

/**
 *	Generated from IDL interface "FDFrIterator_I"
 *	@author JacORB IDL compiler V 2.2, 7-May-2004
 */

public interface FDFrIterator_I
	extends FDFrIterator_IOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity
{
}
